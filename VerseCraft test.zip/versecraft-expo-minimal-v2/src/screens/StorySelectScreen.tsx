import React, { useEffect, useMemo, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, Alert } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../nav/types";
import { listStoriesAsync } from "../repo/storyRepo";
import { clearRemoteCache } from "../content/remoteContent";

type Props = NativeStackScreenProps<RootStackParamList, "StorySelect">;

type StoryRow = {
  storyId: string;
  title: string;
  subtitle?: string;
  theme: string;
  version: string;
};

export default function StorySelectScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState<"remote" | "local">("local");
  const [stories, setStories] = useState<StoryRow[]>([]);
  const [packFiles, setPackFiles] = useState<Record<string, string>>({});

  async function refresh(force?: boolean) {
    setLoading(true);
    try {
      if (force) await clearRemoteCache();
      const res = await listStoriesAsync();
      setSource(res.source);
      setStories(res.stories as any);
      setPackFiles(res.packFiles ?? {});
    } catch (e: any) {
      Alert.alert("Load failed", e?.message ?? "Unknown error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { refresh(false); }, []);

  const banner = useMemo(() => {
    if (loading) return "Loading…";
    return source === "remote" ? "Content: Remote (GitHub)" : "Content: Local (bundled)";
  }, [loading, source]);

  return (
    <View style={styles.root}>
      <Text style={styles.header}>Select a Story</Text>

      <View style={styles.bannerRow}>
        <Text style={styles.banner}>{banner}</Text>
        <Pressable style={styles.smallBtn} onPress={() => refresh(true)}>
          <Text style={styles.smallBtnText}>Refresh</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.list}>
        {stories.map((s) => (
          <Pressable
            key={s.storyId}
            style={styles.card}
            onPress={() => navigation.navigate("StoryDetails", { storyId: s.storyId, packFile: packFiles[s.storyId] })}
          >
            <Text style={styles.title}>{s.title}</Text>
            {!!s.subtitle && <Text style={styles.subtitle}>{s.subtitle}</Text>}
            <Text style={styles.meta}>{s.theme} • v{s.version}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <Pressable style={styles.storeButton} onPress={() => {}}>
        <Text style={styles.storeText}>Get More from the Store</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, paddingTop: 54, backgroundColor: "#070B1A" },
  header: { color: "#E8D7A3", fontSize: 22, fontWeight: "800", paddingHorizontal: 18, marginBottom: 12 },
  bannerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, marginBottom: 8, gap: 10 },
  banner: { color: "#B9B08A", fontSize: 12, fontWeight: "800" },
  smallBtn: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(201,165,74,0.55)" },
  smallBtnText: { color: "#E8D7A3", fontWeight: "900", fontSize: 12 },
  list: { paddingHorizontal: 18, paddingBottom: 18, gap: 12 },
  card: { padding: 16, borderRadius: 14, borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(20,25,60,0.55)" },
  title: { color: "#E8D7A3", fontSize: 18, fontWeight: "800" },
  subtitle: { color: "#D8C98F", marginTop: 4, fontSize: 13 },
  meta: { color: "#B9B08A", marginTop: 10, fontSize: 12 },
  storeButton: { margin: 18, paddingVertical: 14, borderRadius: 14, borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(0,0,0,0.25)" },
  storeText: { textAlign: "center", color: "#E8D7A3", fontWeight: "800" },
});
