import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../nav/types";

type Props = NativeStackScreenProps<RootStackParamList, "Splash">;

export default function SplashScreen({ navigation }: Props) {
  return (
    <View style={styles.root}>
      <View style={styles.frame}>
        <Text style={styles.title}>VerseCraft</Text>
        <Text style={styles.subtitle}>Your Choices. Your RPG. Your Adventure.</Text>
        <Pressable style={styles.button} onPress={() => navigation.replace("StorySelect")}>
          <Text style={styles.buttonText}>Tap to Start</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#070B1A" },
  frame: { width: "90%", padding: 24, borderWidth: 2, borderRadius: 18, borderColor: "#C9A54A", backgroundColor: "rgba(20,25,60,0.55)" },
  title: { fontSize: 40, fontWeight: "800", textAlign: "center", color: "#E8D7A3" },
  subtitle: { marginTop: 8, fontSize: 14, textAlign: "center", color: "#D8C98F" },
  button: { marginTop: 22, paddingVertical: 14, borderRadius: 12, borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(0,0,0,0.25)" },
  buttonText: { textAlign: "center", fontSize: 16, fontWeight: "700", color: "#E8D7A3" },
});
