import React, { useEffect, useMemo, useState } from "react";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../nav/types";
import { getStoryPackAsync } from "../repo/storyRepo";
import { loadState, clearState } from "../engine/saveManager";
import type { StoryPack } from "../engine/types";

type Props = NativeStackScreenProps<RootStackParamList, "StoryDetails">;

export default function StoryDetailsScreen({ route, navigation }: Props) {
  const { storyId, packFile } = route.params;

  const [pack, setPack] = useState<StoryPack | null>(null);
  const [source, setSource] = useState<"remote" | "local">("local");
  const [hasSave, setHasSave] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const res = await getStoryPackAsync(storyId, packFile);
      if (!mounted) return;
      setPack(res.pack);
      setSource(res.source);
      const s = await loadState(res.pack);
      if (mounted) setHasSave(!!s);
    })();
    return () => { mounted = false; };
  }, [storyId, packFile]);

  const meta = pack?.meta;

  if (!pack || !meta) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={styles.loading}>Loading…</Text>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <Pressable onPress={() => navigation.goBack()} style={styles.back}>
        <Text style={styles.backText}>‹ Back</Text>
      </Pressable>

      <ScrollView contentContainerStyle={styles.body}>
        <Text style={styles.title}>{meta.title}</Text>
        {!!meta.subtitle && <Text style={styles.subtitle}>{meta.subtitle}</Text>}
        <Text style={styles.meta}>
          {meta.theme} • {meta.estimatedLength} • v{meta.version} • {source.toUpperCase()}
        </Text>

        <View style={styles.panel}>
          <Text style={styles.panelTitle}>About</Text>
          <Text style={styles.panelText}>
            This story is loaded from {source === "remote" ? "GitHub (remote content)" : "the bundled app (local fallback)"}.
          </Text>
        </View>
      </ScrollView>

      <View style={styles.dock}>
        <Pressable
          style={[styles.btn, styles.primary]}
          onPress={() => navigation.navigate("Reader", { storyId, packFile, mode: hasSave ? "continue" : "new" })}
        >
          <Text style={styles.btnText}>{hasSave ? "Continue" : "Start Journey"}</Text>
        </Pressable>

        <Pressable
          style={[styles.btn, styles.secondary]}
          onPress={async () => {
            await clearState(storyId);
            setHasSave(false);
          }}
        >
          <Text style={styles.btnText}>Reset Save</Text>
        </Pressable>

        <Pressable style={[styles.btn, styles.secondary]} onPress={() => {}}>
          <Text style={styles.btnText}>Get More from Store</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#070B1A", paddingTop: 48 },
  center: { alignItems: "center", justifyContent: "center" },
  loading: { color: "#E8D7A3", fontWeight: "900" },
  back: { paddingHorizontal: 18, paddingVertical: 10 },
  backText: { color: "#E8D7A3", fontWeight: "800", fontSize: 14 },
  body: { paddingHorizontal: 18, paddingBottom: 140 },
  title: { color: "#E8D7A3", fontSize: 28, fontWeight: "900" },
  subtitle: { color: "#D8C98F", marginTop: 6, fontSize: 14, fontWeight: "700" },
  meta: { color: "#B9B08A", marginTop: 10, fontSize: 12 },
  panel: { marginTop: 18, padding: 16, borderRadius: 14, borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(20,25,60,0.55)" },
  panelTitle: { color: "#E8D7A3", fontWeight: "900", marginBottom: 8 },
  panelText: { color: "#D8C98F", lineHeight: 20 },
  dock: { position: "absolute", left: 0, right: 0, bottom: 0, padding: 14, gap: 10, backgroundColor: "rgba(7,11,26,0.92)", borderTopWidth: 1, borderTopColor: "rgba(201,165,74,0.45)" },
  btn: { paddingVertical: 14, borderRadius: 14, borderWidth: 1, borderColor: "#C9A54A" },
  primary: { backgroundColor: "rgba(0,0,0,0.25)" },
  secondary: { backgroundColor: "rgba(20,25,60,0.35)" },
  btnText: { textAlign: "center", color: "#E8D7A3", fontWeight: "900" },
});
