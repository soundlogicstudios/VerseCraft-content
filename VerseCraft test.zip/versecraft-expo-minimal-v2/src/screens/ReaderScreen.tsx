import React, { useEffect, useMemo, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, Alert } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../nav/types";
import { getStoryPackAsync } from "../repo/storyRepo";
import { advanceState, getCurrentNode, isChoiceAvailable } from "../engine/nodeResolver";
import { loadState, makeInitialState, saveState } from "../engine/saveManager";
import type { GameState, StoryPack } from "../engine/types";

type Props = NativeStackScreenProps<RootStackParamList, "Reader">;

export default function ReaderScreen({ route, navigation }: Props) {
  const { storyId, packFile, mode } = route.params;

  const [pack, setPack] = useState<StoryPack | null>(null);
  const [source, setSource] = useState<"remote" | "local">("local");
  const [state, setState] = useState<GameState | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const res = await getStoryPackAsync(storyId, packFile);
        if (!mounted) return;
        setPack(res.pack);
        setSource(res.source);

        const loaded = mode === "continue" ? await loadState(res.pack) : null;
        const next = loaded ?? makeInitialState(res.pack);
        if (mounted) setState(next);
      } catch (e: any) {
        Alert.alert("Load failed", e?.message ?? "Unknown error");
      }
    })();
    return () => { mounted = false; };
  }, [storyId, packFile, mode]);

  const node = useMemo(() => (pack && state ? getCurrentNode(pack, state) : null), [pack, state]);

  async function pickChoice(idx: number) {
    if (!pack || !state || !node || !node.choices) return;
    try {
      const next = advanceState(pack, state, idx);
      setState(next);
      await saveState(next);
    } catch (e: any) {
      Alert.alert("Cannot choose", e?.message ?? "Unknown error");
    }
  }

  if (!pack || !state || !node) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={styles.text}>Loading…</Text>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <View style={styles.top}>
        <Pressable onPress={() => navigation.goBack()} style={styles.topBtn}>
          <Text style={styles.topBtnText}>‹ Details</Text>
        </Pressable>
        <Text style={styles.topTitle}>{pack.meta.title} ({source.toUpperCase()})</Text>
        <Pressable onPress={() => navigation.replace("StorySelect")} style={styles.topBtn}>
          <Text style={styles.topBtnText}>Stories</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.statsRow}>
          {Object.entries(state.stats).slice(0, 5).map(([k, v]) => (
            <View key={k} style={styles.statPill}>
              <Text style={styles.statKey}>{k.toUpperCase()}</Text>
              <Text style={styles.statVal}>{v}</Text>
            </View>
          ))}
        </View>

        <View style={styles.card}>
          <Text style={styles.text}>{node.text}</Text>
          {!!node.ending && (
            <View style={styles.ending}>
              <Text style={styles.endingTitle}>Ending: {node.ending.type.toUpperCase()}</Text>
              <Text style={styles.endingText}>{node.ending.summary}</Text>
            </View>
          )}
        </View>

        {!node.ending && node.choices && (
          <View style={styles.choices}>
            {node.choices.map((c, idx) => {
              const ok = isChoiceAvailable(c, state);
              return (
                <Pressable
                  key={idx}
                  style={[styles.choiceBtn, !ok && styles.choiceBtnDisabled]}
                  disabled={!ok}
                  onPress={() => pickChoice(idx)}
                >
                  <Text style={styles.choiceText}>{c.label}</Text>
                </Pressable>
              );
            })}
          </View>
        )}

        {node.ending && (
          <View style={styles.choices}>
            <Pressable
              style={styles.choiceBtn}
              onPress={async () => {
                const fresh = makeInitialState(pack);
                setState(fresh);
                await saveState(fresh);
              }}
            >
              <Text style={styles.choiceText}>Restart</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#070B1A", paddingTop: 48 },
  center: { alignItems: "center", justifyContent: "center" },
  top: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14, paddingBottom: 10 },
  topBtn: { paddingVertical: 8, paddingHorizontal: 10, borderWidth: 1, borderColor: "rgba(201,165,74,0.55)", borderRadius: 12 },
  topBtnText: { color: "#E8D7A3", fontWeight: "800" },
  topTitle: { color: "#E8D7A3", fontWeight: "900", fontSize: 12, maxWidth: "56%", textAlign: "center" },
  body: { paddingHorizontal: 18, paddingBottom: 28, gap: 14 },
  statsRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  statPill: { borderWidth: 1, borderColor: "rgba(201,165,74,0.45)", backgroundColor: "rgba(20,25,60,0.45)", paddingVertical: 6, paddingHorizontal: 10, borderRadius: 999, flexDirection: "row", gap: 8, alignItems: "center" },
  statKey: { color: "#B9B08A", fontSize: 10, fontWeight: "900" },
  statVal: { color: "#E8D7A3", fontSize: 12, fontWeight: "900" },
  card: { borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(20,25,60,0.55)", borderRadius: 16, padding: 16 },
  text: { color: "#E8D7A3", lineHeight: 22, fontSize: 15 },
  choices: { gap: 10 },
  choiceBtn: { borderWidth: 1, borderColor: "#C9A54A", backgroundColor: "rgba(0,0,0,0.25)", borderRadius: 14, paddingVertical: 14, paddingHorizontal: 12 },
  choiceBtnDisabled: { opacity: 0.5 },
  choiceText: { color: "#E8D7A3", fontWeight: "900" },
  ending: { marginTop: 14, padding: 12, borderRadius: 14, borderWidth: 1, borderColor: "rgba(201,165,74,0.45)", backgroundColor: "rgba(0,0,0,0.20)", gap: 6 },
  endingTitle: { color: "#E8D7A3", fontWeight: "900" },
  endingText: { color: "#D8C98F" },
});
