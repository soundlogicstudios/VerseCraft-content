import AsyncStorage from "@react-native-async-storage/async-storage";
import type { StoryMeta, StoryPack } from "../engine/types";
import { CONTENT_BASE_URL, CONTENT_CACHE_TTL_MS } from "../config/content";

type Catalog = {
  version: string;
  packs: Array<{
    storyId: string;
    title: string;
    subtitle?: string;
    theme: string;
    category: "core" | "classic_pack";
    version: string;
    publicDomain?: boolean;
    estimatedLength: string;
    packFile: string;
  }>;
};

const kCatalog = "vc_remote_catalog_v1";
const kPack = (storyId: string) => `vc_remote_pack_${storyId}_v1`;

// --- helpers ---
async function getCache<T>(key: string): Promise<{ value: T; savedAt: number } | null> {
  const raw = await AsyncStorage.getItem(key);
  if (!raw) return null;
  try { return JSON.parse(raw) as any; } catch { return null; }
}
async function setCache<T>(key: string, value: T): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify({ value, savedAt: Date.now() }));
}

function requireConfiguredBaseUrl(): string {
  if (!CONTENT_BASE_URL || CONTENT_BASE_URL.includes("PASTE_YOUR_GITHUB_RAW_BASE_URL_HERE")) {
    throw new Error("CONTENT_BASE_URL not set. Open src/config/content.ts and paste your GitHub RAW base URL.");
  }
  return CONTENT_BASE_URL.replace(/\/$/, "");
}

// --- API ---
export async function fetchRemoteCatalog(opts?: { force?: boolean }): Promise<Catalog> {
  const force = !!opts?.force;

  if (!force) {
    const cached = await getCache<Catalog>(kCatalog);
    if (cached && Date.now() - cached.savedAt < CONTENT_CACHE_TTL_MS) return cached.value;
  }

  const base = requireConfiguredBaseUrl();
  const url = `${base}/catalog.json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch catalog: ${res.status}`);
  const catalog = (await res.json()) as Catalog;

  await setCache(kCatalog, catalog);
  return catalog;
}

export async function fetchRemotePack(storyId: string, packFile: string, opts?: { force?: boolean }): Promise<StoryPack> {
  const force = !!opts?.force;

  if (!force) {
    const cached = await getCache<StoryPack>(kPack(storyId));
    if (cached && Date.now() - cached.savedAt < CONTENT_CACHE_TTL_MS) return cached.value;
  }

  const base = requireConfiguredBaseUrl();
  const url = `${base}/${packFile}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch pack (${storyId}): ${res.status}`);
  const pack = (await res.json()) as StoryPack;

  await setCache(kPack(storyId), pack);
  return pack;
}

export async function clearRemoteCache(): Promise<void> {
  const keys = await AsyncStorage.getAllKeys();
  const toRemove = keys.filter(k => k === kCatalog || k.startsWith("vc_remote_pack_"));
  if (toRemove.length) await AsyncStorage.multiRemove(toRemove);
}

// Convert catalog entry to StoryMeta-compatible (we keep it simple)
export function catalogEntryToMeta(e: Catalog["packs"][number]): StoryMeta {
  return {
    storyId: e.storyId,
    title: e.title,
    subtitle: e.subtitle,
    author: e.publicDomain ? "Public Domain" : "Original",
    publicDomain: !!e.publicDomain,
    category: e.category,
    theme: e.theme,
    version: e.version,
    estimatedLength: e.estimatedLength,
    entryNode: "intro",
    tags: [],
  };
}
