import { Choice, GameState, Node, StoryPack } from "./types";

export function getCurrentNode(story: StoryPack, state: GameState): Node {
  const node = story.nodes[state.currentNodeId];
  if (!node) throw new Error(`Missing node: ${state.currentNodeId}`);
  return node;
}

export function isChoiceAvailable(choice: Choice, state: GameState): boolean {
  if (!choice.requires) return true;
  for (const [k, min] of Object.entries(choice.requires)) {
    const v = state.stats[k] ?? 0;
    if (v < (min ?? 0)) return false;
  }
  return true;
}

export function applyEffects(state: GameState, choice: Choice): GameState {
  if (!choice.effects) return { ...state, updatedAt: Date.now() };
  const nextStats = { ...state.stats };
  for (const [k, delta] of Object.entries(choice.effects)) {
    const cur = nextStats[k] ?? 0;
    nextStats[k] = cur + (delta ?? 0);
  }
  return { ...state, stats: nextStats, updatedAt: Date.now() };
}

export function advanceState(story: StoryPack, state: GameState, choiceIndex: number): GameState {
  const node = getCurrentNode(story, state);

  if (node.ending) throw new Error("Cannot advance: story has ended.");
  if (!node.choices || node.choices.length === 0) throw new Error(`No choices at node: ${state.currentNodeId}`);
  if (choiceIndex < 0 || choiceIndex >= node.choices.length) throw new Error("Invalid choice index.");

  const choice = node.choices[choiceIndex];
  if (!isChoiceAvailable(choice, state)) throw new Error("Choice requirements not met.");
  if (!story.nodes[choice.next]) throw new Error(`Choice points to missing node: ${choice.next}`);

  const withEffects = applyEffects(state, choice);
  return {
    ...withEffects,
    storyId: story.meta.storyId,
    storyVersion: story.meta.version,
    currentNodeId: choice.next,
    updatedAt: Date.now(),
  };
}
