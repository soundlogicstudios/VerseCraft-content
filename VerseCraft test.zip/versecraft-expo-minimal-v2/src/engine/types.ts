export type Stats = Record<string, number>;

export type Choice = {
  label: string;
  next: string;
  effects?: Partial<Record<string, number>>;
  requires?: Partial<Record<string, number>>;
};

export type Ending = {
  type: "good" | "bad" | "ambiguous" | "secret";
  summary: string;
};

export type Node = {
  text: string;
  choices?: Choice[];
  ending?: Ending;
};

export type StoryMeta = {
  storyId: string;
  title: string;
  subtitle?: string;
  author?: string;
  publicDomain?: boolean;
  category: "core" | "classic_pack";
  theme: string;
  version: string;
  estimatedLength: string;
  entryNode: string;
  tags?: string[];
};

export type StoryPack = {
  meta: StoryMeta;
  nodes: Record<string, Node>;
};

export type GameState = {
  storyId: string;
  storyVersion: string;
  currentNodeId: string;
  stats: Stats;
  updatedAt: number;
};
