import AsyncStorage from "@react-native-async-storage/async-storage";
import type { GameState, StoryPack } from "./types";

const keyFor = (storyId: string) => `versecraft_save_${storyId}`;

export function makeInitialState(story: StoryPack): GameState {
  return {
    storyId: story.meta.storyId,
    storyVersion: story.meta.version,
    currentNodeId: story.meta.entryNode,
    stats: { health: 5, morale: 5, supplies: 5, reputation: 0, luck: 0 },
    updatedAt: Date.now(),
  };
}

export async function loadState(story: StoryPack): Promise<GameState | null> {
  const raw = await AsyncStorage.getItem(keyFor(story.meta.storyId));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as GameState;
  } catch {
    return null;
  }
}

export async function saveState(state: GameState): Promise<void> {
  await AsyncStorage.setItem(keyFor(state.storyId), JSON.stringify(state));
}

export async function clearState(storyId: string): Promise<void> {
  await AsyncStorage.removeItem(keyFor(storyId));
}
