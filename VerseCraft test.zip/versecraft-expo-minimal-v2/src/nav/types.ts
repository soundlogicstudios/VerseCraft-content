export type RootStackParamList = {
  Splash: undefined;
  StorySelect: undefined;
  StoryDetails: { storyId: string; packFile?: string };
  Reader: { storyId: string; packFile?: string; mode: "continue" | "new" };
};
