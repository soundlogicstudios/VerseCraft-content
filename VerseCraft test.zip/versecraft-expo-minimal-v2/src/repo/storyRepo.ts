import type { StoryPack, StoryMeta } from "../engine/types";
import { fetchRemoteCatalog, fetchRemotePack, catalogEntryToMeta } from "../content/remoteContent";

// Local bundled story packs (fallback / offline)
import paintMeta from "../../stories/core/paint_the_sky/meta.json";
import paintNodes from "../../stories/core/paint_the_sky/nodes.json";

import codeMeta from "../../stories/core/code_blue/meta.json";
import codeNodes from "../../stories/core/code_blue/nodes.json";

import backMeta from "../../stories/core/back_rooms/meta.json";
import backNodes from "../../stories/core/back_rooms/nodes.json";

import loreMeta from "../../stories/core/lore_of_lorecraft/meta.json";
import loreNodes from "../../stories/core/lore_of_lorecraft/nodes.json";

import cosmosMeta from "../../stories/core/creation_of_the_cosmos/meta.json";
import cosmosNodes from "../../stories/core/creation_of_the_cosmos/nodes.json";

import crimsonMeta from "../../stories/core/crimson_seagull_ember_crown/meta.json";
import crimsonNodes from "../../stories/core/crimson_seagull_ember_crown/nodes.json";

import relicMeta from "../../stories/core/relic_of_sylara/meta.json";
import relicNodes from "../../stories/core/relic_of_sylara/nodes.json";

import wastelandMeta from "../../stories/core/wasteland_story/meta.json";
import wastelandNodes from "../../stories/core/wasteland_story/nodes.json";

import worldLoreMeta from "../../stories/core/world_of_lorecraft/meta.json";
import worldLoreNodes from "../../stories/core/world_of_lorecraft/nodes.json";

const localPacks: StoryPack[] = [
  { meta: paintMeta as unknown as StoryMeta, nodes: paintNodes as any },
  { meta: codeMeta as unknown as StoryMeta, nodes: codeNodes as any },
  { meta: backMeta as unknown as StoryMeta, nodes: backNodes as any },
  { meta: loreMeta as unknown as StoryMeta, nodes: loreNodes as any },
  { meta: cosmosMeta as unknown as StoryMeta, nodes: cosmosNodes as any },
  { meta: crimsonMeta as unknown as StoryMeta, nodes: crimsonNodes as any },
  { meta: relicMeta as unknown as StoryMeta, nodes: relicNodes as any },
  { meta: wastelandMeta as unknown as StoryMeta, nodes: wastelandNodes as any },
  { meta: worldLoreMeta as unknown as StoryMeta, nodes: worldLoreNodes as any },
];

function getLocalMeta(): StoryMeta[] {
  return localPacks.map(p => p.meta);
}

export async function listStoriesAsync(): Promise<{ source: "remote" | "local"; stories: StoryMeta[]; packFiles?: Record<string, string> }> {
  try {
    const catalog = await fetchRemoteCatalog();
    const packFiles: Record<string, string> = {};
    const stories = catalog.packs.map(p => {
      packFiles[p.storyId] = p.packFile;
      return catalogEntryToMeta(p);
    });
    return { source: "remote", stories, packFiles };
  } catch {
    return { source: "local", stories: getLocalMeta() };
  }
}

export async function getStoryPackAsync(storyId: string, packFile?: string): Promise<{ source: "remote" | "local"; pack: StoryPack }> {
  // If we have a packFile (from catalog), try remote
  if (packFile) {
    try {
      const remote = await fetchRemotePack(storyId, packFile);
      return { source: "remote", pack: remote };
    } catch {
      // fall through to local
    }
  }

  const found = localPacks.find(p => p.meta.storyId === storyId);
  if (!found) throw new Error(`Story not found locally: ${storyId}`);
  return { source: "local", pack: found };
}
