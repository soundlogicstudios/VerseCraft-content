/**
 * VerseCraft Remote Content Config
 *
 * Put your GitHub RAW base URL here once you upload the JSON bundle.
 * Example:
 *   https://raw.githubusercontent.com/<YOU>/<REPO>/main
 */
export const CONTENT_BASE_URL = "PASTE_YOUR_GITHUB_RAW_BASE_URL_HERE";

// Time-to-live for cached content (ms). For MVP you can leave this high.
export const CONTENT_CACHE_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days
