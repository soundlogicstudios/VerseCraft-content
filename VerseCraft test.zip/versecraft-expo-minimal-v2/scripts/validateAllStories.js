#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..", "stories");

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}
function isObj(x) { return x && typeof x === "object" && !Array.isArray(x); }

function validateStory(storyDir) {
  const metaPath = path.join(storyDir, "meta.json");
  const nodesPath = path.join(storyDir, "nodes.json");
  const errors = [];
  const warnings = [];

  if (!fs.existsSync(metaPath) || !fs.existsSync(nodesPath)) {
    errors.push(`Missing meta.json or nodes.json in ${storyDir}`);
    return { ok: false, errors, warnings };
  }

  const meta = readJson(metaPath);
  const nodes = readJson(nodesPath);

  const requiredMeta = ["storyId","title","category","theme","version","estimatedLength","entryNode"];
  for (const k of requiredMeta) if (!meta[k]) errors.push(`meta.${k} missing`);
  if (!isObj(nodes)) errors.push("nodes.json must be an object keyed by nodeId");

  if (meta.entryNode && nodes && !nodes[meta.entryNode]) errors.push(`entryNode "${meta.entryNode}" does not exist`);

  const nodeIds = new Set(Object.keys(nodes || {}));
  const referenced = new Set();

  for (const [id, node] of Object.entries(nodes || {})) {
    if (!node || typeof node.text !== "string") errors.push(`node "${id}" missing text`);

    const hasEnding = !!node.ending;
    const hasChoices = Array.isArray(node.choices);
    if (hasEnding && hasChoices) errors.push(`ending node "${id}" must not have choices`);

    if (hasChoices) {
      if (node.choices.length > 4) errors.push(`node "${id}" has > 4 choices`);
      node.choices.forEach((choice, idx) => {
        if (!choice || typeof choice.label !== "string") errors.push(`node "${id}" choice[${idx}] missing label`);
        if (!choice || typeof choice.next !== "string") errors.push(`node "${id}" choice[${idx}] missing next`);
        if (choice && typeof choice.next === "string") referenced.add(choice.next);

        if (choice.effects && !isObj(choice.effects)) errors.push(`node "${id}" choice[${idx}] effects must be object`);
        if (choice.requires && !isObj(choice.requires)) errors.push(`node "${id}" choice[${idx}] requires must be object`);
      });
    }

    if (hasEnding) {
      if (!isObj(node.ending)) errors.push(`node "${id}" ending must be object`);
      else {
        if (!node.ending.type) errors.push(`node "${id}" ending.type missing`);
        if (!node.ending.summary) errors.push(`node "${id}" ending.summary missing`);
      }
    }
  }

  for (const nextId of referenced) {
    if (!nodeIds.has(nextId)) errors.push(`choice points to missing node "${nextId}"`);
  }

  // Orphan warning (non-fatal)
  const orphans = [...nodeIds].filter(n => n !== meta.entryNode && !referenced.has(n));
  if (orphans.length) warnings.push(`Orphan nodes (not referenced): ${orphans.join(", ")}`);

  return { ok: errors.length === 0, errors, warnings };
}

function findStoryDirs(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const ent of entries) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      if (fs.existsSync(path.join(full, "meta.json")) && fs.existsSync(path.join(full, "nodes.json"))) out.push(full);
      else out.push(...findStoryDirs(full));
    }
  }
  return out;
}

const storyDirs = findStoryDirs(ROOT);
if (!storyDirs.length) {
  console.error("No stories found under:", ROOT);
  process.exit(1);
}

let failed = 0;
for (const d of storyDirs) {
  const res = validateStory(d);
  const rel = path.relative(path.join(__dirname, ".."), d);
  if (!res.ok) {
    failed++;
    console.error(`\n❌ ${rel}`);
    res.errors.forEach(e => console.error("  -", e));
    res.warnings.forEach(w => console.warn("  !", w));
  } else {
    console.log(`✅ ${rel}`);
    res.warnings.forEach(w => console.warn("  !", w));
  }
}

if (failed) {
  console.error(`\nValidation failed for ${failed} stor${failed === 1 ? "y" : "ies"}.`);
  process.exit(1);
} else {
  console.log("\nAll stories validated.");
}
